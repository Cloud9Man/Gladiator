mult = [
    "tavaseaseaer mamer",
    "boeasesaeasts",
    "nabesaeaseags",
    "bad",
    "youeasease dog water"
]
# Never add a comma after the last "*your phrase here*", it will crash, you can change it but you may break it!