from ast import For
import numbers
import random
from socket import timeout
import time
import string
from turtle import title
import pyautogui
import colorama
import clipboard
import pickle
import os
from colorama import Fore, Back, Style
from plyer import notification
colorama.init(autoreset=True)

try:
    import config
    from config import mult
except:
    print("Couldn't import the config file..")
    pass

letters = [
    "q",
    "w",
    "e",
    "r",
    "t",
    "y",
    "u",
    "i",
    "o",
    "p",
    "a",
    "s",
    "d",
    "f",
    "g",
    "h",
    "j",
    "k",
    "l",
    "z",
    "x",
    "c",
    "v",
    "b",
    "n",
    "m"
]


def thegodpart():
    print(Fore.CYAN + """
     _____  _                    _     _____                                                 
    /  __ \| |                  | |   /  ___|                                                
    | /  \/| |  ___   _   _   __| |   \ `--.  _ __    __ _  _ __ ___   _ __ ___    ___  _ __ 
    | |    | | / _ \ | | | | / _` |    `--. \| '_ \  / _` || '_ ` _ \ | '_ ` _ \  / _ \| '__|
    | \__/\| || (_) || |_| || (_| |   /\__/ /| |_) || (_| || | | | | || | | | | ||  __/| |   
     \____/|_| \___/  \__,_| \__,_|   \____/ | .__/  \__,_||_| |_| |_||_| |_| |_| \___||_|   
                                             | |                                             
                                             |_|                                             
    """)
    print("Made by Cloud9#8279, for educational purposes. Contact me for support.")
    print(" ")
    print(Fore.MAGENTA + "--Normal section--")
    print("[1] Spam one word (one phrase)")
    print("[2] Spam multiple words (multiple phrases)")
    print("[3] Spam random letters")
    print(" ")
    print(Fore.MAGENTA + "--Discord section--")
    print("[4] Spam one word (one phrase) with delay")
    print("[5] Spam multiple words (multiple phrases) with delay")
    print("[6] Spam random letters with delay")
    print("[7] Create a Discord invite with a vanity")

    print(" ")
    print(Fore.MAGENTA + "--Your choice--")
    print("[0] Exit the message spammer")
    a = int(input("[?]: "))
    if a == 1:
        k = input("Enter the word you want to spam: ")
        count = int(input("How many times do you want to spam *" + k + "*?: "))
        print("You have 5 seconds, change your windows or focus on a text box.")
        Fore.RESET
        time.sleep(5)
        for i in range(count):
            pyautogui.typewrite(k)
            pyautogui.press("enter")
            time.sleep(0.1)
        message1 = "Spam complete. You have spammed *" + k + "* " + str(count) + " times!"
        notification.notify(title = "Spam complete", message = message1, app_name = "Cloud Spammer", timeout = 10, toast = False)
        #print(Fore.GREEN + "Spam complete. You have spammed *" + k + "* " + str(count) + " times!")
        thegodpart()
        print(" ")

    elif a == 2:
        print("Update your config file, and then continue.")
        print("Press `Enter` on your keyboard once ready!")
        input("")
        l = int(input("How many times do you want to spam the message?: "))
        print(Fore.YELLOW + "You have 5 seconds, change your windows or focus on a text box.")
        time.sleep(5)
        for a in range(l):
            for i in mult:
                pyautogui.typewrite(i)
                pyautogui.press("enter")
                time.sleep(0.1)
        message1 = "Spam complete. Spammed everything in the config file " + str(l) + " times!"
        notification.notify(title = "Spam complete", message = message1, app_name = "Cloud Spammer", timeout = 10, toast = False)
        #print(Fore.GREEN + "Spammed everything in the config file " + str(l) + " times!")
        thegodpart()
        print(" ")
    elif a == 3:
        count = int(input("How many times do you want to spam to spam the letters?: "))
        print(Fore.YELLOW + "You have 5 seconds, change your windows or focus on a text box.")
        time.sleep(5)
        for i in range(count):
            pyautogui.typewrite(random.choice(letters))
            pyautogui.press("enter")
            time.sleep(0.1)
        message1 = "Spam complete. You have spammed random letters " + str(count) + " times!"
        notification.notify(title = "Spam complete", message = message1, app_name = "Cloud Spammer", timeout = 10, toast = False)
        #print(Fore.GREEN + "Spam complete. You have spammed random letters " + str(count) + " times!")
        thegodpart()
        print(" ")
    elif a == 4:
        k = input("Enter the word you want to spam: ")
        count = int(input("How many times do you want to spam *" + k + "*?: "))
        print(Fore.YELLOW + "You have 5 seconds, change your windows or focus on a text box.")
        time.sleep(5)
        for i in range(count):
            pyautogui.typewrite(k)
            pyautogui.press("enter")
            time.sleep(0.8)
        message1 = "Spam complete. You have spammed *" + k + "* " + str(count) + " times!"
        notification.notify(title = "Spam complete", message = message1, app_name = "Cloud Spammer", timeout = 10, toast = False)
        #print(Fore.GREEN + "Spam complete. You have spammed *" + k + "* " + str(count) + " times!")
        thegodpart()
        print(" ")

    elif a == 5:
        print("Update your config file, and then continue.")
        print("Press `Enter` on your keyboard once ready!")
        input("")
        l = int(input("How many times do you want to spam the message?: "))
        print(Fore.YELLOW + "You have 5 seconds, change your windows or focus on a text box.")
        time.sleep(5)
        for a in range(l):
            for i in mult:
                pyautogui.typewrite(i)
                pyautogui.press("enter")
                time.sleep(0.5)
        message1 = "Spammed everything in config file " + str(l) + " times!"
        notification.notify(title = "Spam complete", message = message1, app_name = "Cloud Spammer", timeout = 10, toast = False)
        #print(Fore.GREEN + "Spammed everything in config file " + str(l) + " times!")
        thegodpart()
        print(" ")
    elif a == 6:
        count = int(input("How many times do you want to spam to spam the letters?: "))
        print(Fore.YELLOW + "You have 5 seconds, change your windows or focus on a text box.")
        time.sleep(5)
        for i in range(count):
            pyautogui.typewrite(random.choice(letters))
            pyautogui.press("enter")
            time.sleep(0.5)
        message1 = "Spam complete. You have spammed random letters " + str(count) + " times!"
        notification.notify(title = "Spam complete", message = message1, app_name = "Cloud Spammer", timeout = 10, toast = False)
        #print(Fore.GREEN + "Spam complete. You have spammed random letters " + str(count) + " times!")
        thegodpart()
        print(" ")
    elif a == 7:
        server = input("🡣 Please input the server invite: 🡣\n")
        invite = input("What should be he new invite name?\n")
        url = "discοrd.gg/" + invite + "||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||" + server
        clipboard.copy(url)
        print(url)
        thegodpart()
    elif a == 0:
        exit("User has exited..")
    else:
        print(" ")
        print("Invalid choice. Try again!")
        thegodpart()
thegodpart()